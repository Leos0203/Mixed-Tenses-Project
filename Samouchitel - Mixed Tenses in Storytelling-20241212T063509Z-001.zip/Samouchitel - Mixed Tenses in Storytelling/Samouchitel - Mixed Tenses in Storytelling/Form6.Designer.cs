﻿namespace Samouchitel___Mixed_Tenses_in_Storytelling
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form6));
            this.label1 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(263, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(238, 39);
            this.label1.TabIndex = 2;
            this.label1.Text = "Sample Story";
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.PaleGreen;
            this.listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 18;
            this.listBox1.Items.AddRange(new object[] {
            "The Forgotten Journal:",
            "Last summer, while I was cleaning out my grandmother’s attic,I found an old leath" +
                "er-bound journal.",
            "It looked like it hadn’t been opened in decades, and the pages smelled faintly of" +
                " cedar and dust.",
            "As I flipped through the yellowed pages, I noticed that most of the entries were " +
                "written in a neat, cursive hand.  ",
            "One entry caught my attention: \"April 15, 1945. Today, the war finally ended for " +
                "us.",
            "\"I remembered how my grandmother used to tell us stories about her youth during t" +
                "he war,",
            "but she had never mentioned keeping a journal.  ",
            "Now, as I sit here reading her words, I feel as though I’m transported back in ti" +
                "me.",
            "Her descriptions are so vivid that I can almost hear the rumble of planes overhea" +
                "d and",
            "smell the damp, earthy scent of the cellar where she and her family had hidden.  " +
                "",
            "By the time I finish the journal, I know I will have discovered a side of my gran" +
                "dmother I never knew.",
            "Perhaps next week, I’ll bring it to the family reunion and share it with everyone" +
                ". For now, though,",
            "I am savoring these quiet moments, connecting with her through her words.  ",
            "",
            "Tenses Used:  ",
            "1. Past Simple: To narrate the main events (e.g., \"I found an old leather-bound j" +
                "ournal\").  ",
            "2. Past Continuous: For background actions (e.g., \"I was cleaning out my grandmot" +
                "her’s attic\").  ",
            "3. Present Simple: For current thoughts and feelings (e.g., \"I feel as though I’m" +
                " transported back\").  ",
            "4. Future Simple: To hint at upcoming actions (e.g., \"Perhaps next week, I’ll bri" +
                "ng it\").  ",
            "5. Present Continuous: For immediate, ongoing actions (e.g., \"I am savoring these" +
                " quiet moments\").  "});
            this.listBox1.Location = new System.Drawing.Point(30, 71);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(749, 310);
            this.listBox1.TabIndex = 3;
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Samouchitel___Mixed_Tenses_in_Storytelling.Properties.Resources.empty_blank_schoolboard_background_school_board_template_photo;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form6";
            this.Text = "Sample Story Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBox1;
    }
}