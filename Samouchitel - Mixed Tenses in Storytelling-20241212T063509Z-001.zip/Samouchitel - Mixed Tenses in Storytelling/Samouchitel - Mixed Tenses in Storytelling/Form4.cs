﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Samouchitel___Mixed_Tenses_in_Storytelling
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
            button1.Visible = button2.Visible = button3.Visible = false;
            listBox1.Visible = listBox2.Visible = listBox3.Visible = listBox4.Visible = false;
            label2.Visible = label3.Visible = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Mixed Tenses in Storytelling")
            {
                listBox1.Visible = true;
                button1.Visible = button2.Visible = button3.Visible = true;
                label2.Visible = label3.Visible = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox1.Visible)
            {
                listBox1.Visible = false;
                listBox2.Visible = true;
            }
            else if (listBox2.Visible)
            {
                listBox2.Visible = false;
                listBox3.Visible = true;
            }
            else if (listBox3.Visible)
            {
                listBox3.Visible = false;
                listBox4.Visible = true;
            }
            else
            {
                listBox1.Visible = true;
                listBox2.Visible = listBox3.Visible = listBox4.Visible = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6();
            form6.Show();
        }
    }
}
