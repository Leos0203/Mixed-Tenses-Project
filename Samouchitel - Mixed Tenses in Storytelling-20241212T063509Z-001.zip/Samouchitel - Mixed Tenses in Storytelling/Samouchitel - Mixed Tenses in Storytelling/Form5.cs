﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Samouchitel___Mixed_Tenses_in_Storytelling
{
    public partial class Form5 : Form
    {
        int points = 0;

        public Form5()
        {
            InitializeComponent();
            groupBox2.Visible = groupBox3.Visible = groupBox4.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (groupBox1.Visible)
            {
                label2.Text = "Explanation: B uses the past perfect ('had already eaten')\nto describe an action completed before another action\nin the past ('they arrived').\nThe other options misuse tense pairs.";
                radioButton2.BackColor = Color.Lime;
                if (radioButton2.Checked)
                    points++;
            }
            else if (groupBox2.Visible)
            {
                label2.Text = "Explanation: B correctly mixes present simple ('he is tired') with past simple\n('he stayed up') to explain a present condition caused by a past action.";
                radioButton7.BackColor = Color.Lime;
                if (radioButton7.Checked)
                    points++;
            }
            else if (groupBox3.Visible)
            {
                label2.Text = "Explanation: C uses past perfect continuous ('had been waiting') to\ndescribe a prolonged action that ended when another\naction occurred in the past ('the bus arrived').";
                radioButton10.BackColor = Color.Lime;
                if (radioButton10.Checked)
                    points++;
            }
            else if (groupBox4.Visible)
            {
                label2.Text = "Explanation: D uses past continuous ('was reading') to describe an ongoing\naction interrupted by another action in the past simple ('power went out').";
                radioButton13.BackColor = Color.Lime;
                if (radioButton13.Checked)
                    points++;
            }
            label3.Text = $"{points}/4";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (groupBox1.Visible)
            {
                groupBox2.Visible = true;
                groupBox1.Visible = false;
                label2.Text = "Explanation:";
            }
            else if (groupBox2.Visible)
            {
                groupBox3.Visible = true;
                groupBox2.Visible = false;
                label2.Text = "Explanation:";
            }
            else if (groupBox3.Visible)
            {
                groupBox4.Visible = true;
                groupBox3.Visible = false;
                label2.Text = "Explanation:";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (groupBox2.Visible)
            {
                groupBox1.Visible = true;
                groupBox2.Visible = false;
                label2.Text = "Explanation:";
            }
            else if (groupBox3.Visible)
            {
                groupBox2.Visible = true;
                groupBox3.Visible = false;
                label2.Text = "Explanation:";
            }
            else if (groupBox4.Visible)
            {
                groupBox3.Visible = true;
                groupBox4.Visible = false;
                label2.Text = "Explanation:";
            }
        }

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton10_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton11_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton12_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
