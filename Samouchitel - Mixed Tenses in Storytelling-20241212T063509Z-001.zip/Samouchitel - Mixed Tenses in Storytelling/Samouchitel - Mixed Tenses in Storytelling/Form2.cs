﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Samouchitel___Mixed_Tenses_in_Storytelling
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!File.Exists("../../Resources/login.txt"))
            {
                MessageBox.Show("No account found!", "Log In Attempt", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            
            StreamReader sr = new StreamReader("../../Resources/login.txt");
            string username = sr.ReadLine();
            string password = sr.ReadLine();
            sr.Close();

            if (username == textBox1.Text && password == textBox2.Text)
            {
                DialogResult result = MessageBox.Show("Log In Successful!", "Log In Attempt", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                if (result == DialogResult.OK)
                {
                    Form4 form4 = new Form4();
                    form4.Show();
                    this.Hide();
                }
            }
            else
            MessageBox.Show("Wrong credentials!", "Log In Attempt", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
